﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1.pages
{
    /// <summary>
    /// Логика взаимодействия для MoviePage.xaml
    /// </summary>
    public partial class MoviePage : Page
    {
        public Films SelectedFilm { get; set; }
        public List<Sessions> Sessions { get; set; }
        public string GenresString { get; set; }

        public MoviePage(Films film)
        {
            InitializeComponent();
            SelectedFilm = film;
            DataContext = this;
        }
    }
}
